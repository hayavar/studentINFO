create standalone executables from Python scripts


